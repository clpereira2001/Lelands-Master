﻿using System.Collections;

namespace Vauction.Configuration
{
	public interface IPropertyConfigurationCollection : IEnumerable
	{
	}
}
