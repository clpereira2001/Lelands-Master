namespace Vauction
{
  partial class VauctionDataContext
  {
  }
}
