﻿using System;

namespace Vauction.Models
{
  partial class CommissionRate : ICommissionRate
  {
    public static Byte DefaultCommission
    {
      get { return 0; }
    }
  }
}
