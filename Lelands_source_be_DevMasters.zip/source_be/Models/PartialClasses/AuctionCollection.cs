﻿using System;

namespace Vauction.Models
{
  [Serializable]
  partial class AuctionCollection : IAuctionCollection
  {
  }
}