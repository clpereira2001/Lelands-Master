﻿using System;

namespace Vauction.Models
{
  [Serializable]
  public partial class BidLogCurrent : IBidLog
  {
  }
}
